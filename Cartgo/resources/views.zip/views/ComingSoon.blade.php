<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Coming Soon ...</title>
@yield('heading')
@yield('heading-exp')
</head>
<body>
<div id="Web_1920__2">
	<a href="/">
	<svg class="Lower_Body">
		<rect id="Lower_Body" rx="0" ry="0" x="0" y="0" width="1920" height="557">
		</rect>
	</svg>


								<!-- Coming Soon Icon Holder -->
	<svg class="Icon_Holder">
		<rect id="Icon_Holder" rx="0" ry="0" x="0" y="0" width="100%" height="442">
		</rect>
	</svg>
	<div class="Rectangle_7"><h2><center>50% OFF</center></h2></div>
	<div class="Rectangle_33"><h2><center>SNAP DEAL</center></h2></div>
	<div class="Rectangle_13"><h2><center>DAILY BONUS</center></h2></div>
	<div class="Rectangle_34"><h2><center>FLASH SALE</center></h2></div>
	<div class="Rectangle_11"><h2><center>CASH BACK</center></h2></div>
	<div class="Rectangle_35"><h2><center>FEST BONUS</center></h2></div>
	<div class="Rectangle_12"><h2><center>99TK SHOP</center></h2></div>
	<div class="Rectangle_36"><h2><center>EID SALE</center></h2></div>

	


	<svg class="Rectangle_18">
		<rect id="Rectangle_18" rx="10" ry="10" x="0" y="0" width="212" height="388">
		</rect>
	</svg>
	<svg class="Rectangle_19">
		<rect id="Rectangle_19" rx="10" ry="10" x="0" y="0" width="212" height="388">
		</rect>
	</svg>
	<svg class="Rectangle_20">
		<rect id="Rectangle_20" rx="10" ry="10" x="0" y="0" width="212" height="388">
		</rect>
	</svg>
	<svg class="Rectangle_21">
		<rect id="Rectangle_21" rx="10" ry="10" x="0" y="0" width="212" height="388">
		</rect>
	</svg>
	
	<div id="DEALS_OF_THE_DAY">
		<span>DEALS OF<br/>THE DAY</span>
	</div>
	<svg class="Rectangle_17">
		<rect id="Rectangle_17" rx="4" ry="4" x="0" y="0" width="440" height="8">
		</rect>
	</svg>
	<svg class="Ellipse_2">
		<ellipse id="Ellipse_2" rx="40" ry="40" cx="40" cy="40">
		</ellipse>
	</svg>
	<svg class="Ellipse_3">
		<ellipse id="Ellipse_3" rx="40" ry="40" cx="40" cy="40">
		</ellipse>
	</svg>
	<svg class="Union_4" viewBox="0 0 178 48">
		<path id="Union_4" d="M 121.1598052978516 47.99970245361328 L 0 47.99970245361328 L 0 27.99990081787109 L 0 19.99979972839355 L 0 0 L 19.99979972839355 0 L 158.0003967285156 0 C 169.0460968017578 0 178.0001983642578 8.954100608825684 178.0001983642578 19.99979972839355 L 178.0001983642578 27.99990081787109 C 178.0001983642578 39.04560089111328 169.0460968017578 47.99970245361328 158.0003967285156 47.99970245361328 L 121.1598052978516 47.99970245361328 Z">
		</path>
	</svg>
	<svg class="Union_5" viewBox="0 0 178 48">
		<path id="Union_5" d="M 121.1598052978516 47.99970245361328 L 0 47.99970245361328 L 0 27.99990081787109 L 0 19.99979972839355 L 0 0 L 19.99979972839355 0 L 158.0003967285156 0 C 169.0460968017578 0 178.0001983642578 8.954100608825684 178.0001983642578 19.99979972839355 L 178.0001983642578 27.99990081787109 C 178.0001983642578 39.04560089111328 169.0460968017578 47.99970245361328 158.0003967285156 47.99970245361328 L 121.1598052978516 47.99970245361328 Z">
		</path>
	</svg>
	<svg class="Union_6" viewBox="0 0 178 48">
		<path id="Union_6" d="M 121.1598052978516 47.99970245361328 L 0 47.99970245361328 L 0 27.99990081787109 L 0 19.99979972839355 L 0 0 L 19.99979972839355 0 L 158.0003967285156 0 C 169.0460968017578 0 178.0001983642578 8.954100608825684 178.0001983642578 19.99979972839355 L 178.0001983642578 27.99990081787109 C 178.0001983642578 39.04560089111328 169.0460968017578 47.99970245361328 158.0003967285156 47.99970245361328 L 121.1598052978516 47.99970245361328 Z">
		</path>
	</svg>
	<svg class="Union_7" viewBox="0 0 178 48">
		<path id="Union_7" d="M 121.1598052978516 47.99970245361328 L 0 47.99970245361328 L 0 27.99990081787109 L 0 19.99979972839355 L 0 0 L 19.99979972839355 0 L 158.0003967285156 0 C 169.0460968017578 0 178.0001983642578 8.954100608825684 178.0001983642578 19.99979972839355 L 178.0001983642578 27.99990081787109 C 178.0001983642578 39.04560089111328 169.0460968017578 47.99970245361328 158.0003967285156 47.99970245361328 L 121.1598052978516 47.99970245361328 Z">
		</path>
	</svg>
	<svg class="Rectangle_29">
		<rect id="Rectangle_29" rx="61" ry="61" x="0" y="0" width="156" height="141">
		</rect>
	</svg>
	<svg class="Rectangle_30">
		<rect id="Rectangle_30" rx="61" ry="61" x="0" y="0" width="156" height="141">
		</rect>
	</svg>
	<svg class="Rectangle_31">
		<rect id="Rectangle_31" rx="61" ry="61" x="0" y="0" width="156" height="141">
		</rect>
	</svg>
	<svg class="Rectangle_32">
		<rect id="Rectangle_32" rx="61" ry="61" x="0" y="0" width="156" height="141">
		</rect>
	</svg>
	<div id="PRODUCT__IMAGE">
		<img src="img/shop/47v1.ico" class="img-below-tag">
	</div>
	<div id="Product_Name">
		<span>Ram Champaign</span>
	</div>
	<div id="PRICE">
		<span>$1640</span>
	</div>
	<div id="ID20_OFF">
		<span>20% OFF</span>
	</div>
	<div id="Group_6">
		<div id="Product_Name_bv">
			<span>Cartridge Box</span>
		</div>
		<div id="PRICE_bw">
			<span>$1200</span>
		</div>
		<div id="ID20_OFF_bx">
			<span>20% OFF</span>
		</div>
	</div>
	<div id="Group_7">
		<div id="Product_Name_bz">
			<span>Framign Cream Cake</span>
		</div>
		<div id="PRICE_b">
			<span>$120</span>
		</div>
		<div id="ID20_OFF_b">
			<span>20% OFF</span>
		</div>
	</div>
	<div id="Group_8">
		<div id="Product_Name_b">
			<span>Asota Drinks</span>
		</div>
		<div id="PRICE_ca">
			<span>$80</span>
		</div>
		<div id="ID20_OFF_ca">
			<span>20% OFF</span>
		</div>
	</div>
	<div id="PRODUCT__IMAGE_b">
		<img src="img/shop/11v1.ico" class="img-below-tag">
	</div>
	<div id="PRODUCT__IMAGE_ca">
		<img src="img/shop/12v1.ico" class="img-below-tag">
	</div>
	<div id="PRODUCT__IMAGE_cb">
		<img src="img/shop/49v1.ico" class="img-below-tag">
	</div>

</a>
@yield('dashboard')	
</div>
</body>
</html>